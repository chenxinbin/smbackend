<?php $__env->startSection('pagestyle'); ?>
<link href="https://cdn.bootcss.com/datatables/1.10.16/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    首页 / 文章 / 分类列表
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
          <div id="buttons">
            <a class="btn btn-md btn-success  " href="<?php echo e(route('backend.cms.category_add')); ?>">
               <i class="fa fa-plus "></i>
              新控制台
            </a>
          </div>
      </div>
      <div class="row">
        <div class="col-12">

              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>名称</th>
                  <th>Slug</th>
                  <th>创建时间</th>
                  <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($category->id); ?></td>
                  <td><?php echo e($category->name); ?></td>
                  <td><?php echo e($category->slug); ?></td>
                  <td><?php echo e($category->created_at); ?></td>
                  <td>
                    <nobr>
                      <a class="btn btn-sm btn-warning" href="<?php echo e(route('backend.cms.category_edit', ['category_id'=>$category->id])); ?>"><i class="fa fa-pencil "></i>编辑</a>
                    </nobr>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>ID</th>
                  <th>名称</th>
                  <th>Slug</th>
                  <th>创建时间</th>
                  <th>操作</th>
                </tr>
                </tfoot>
              </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
<!-- DataTables -->
<script src="https://cdn.bootcss.com/datatables/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.bootcss.com/datatables/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>